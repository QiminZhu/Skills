# Visual question generation (v1.2.0)

## Contract
Add optional `visualization` to `Question`, independent of `cognitiveType`, `answerFormat`, and `grading`. The visualization is an aid or stimulus, not a cognitive type. Use a structured, reproducible data model; never make the only source of truth an opaque image.

```json
{
  "visualization": {
    "type": "binary_tree",
    "data": {
      "nodes": [{"id":"n50","value":50},{"id":"n30","value":30},{"id":"n70","value":70}],
      "edges": [{"from":"n50","to":"n30","label":"left"},{"from":"n50","to":"n70","label":"right"}]
    },
    "interactive": false,
    "altText": "Root 50 with left child 30 and right child 70"
  }
}
```

## Supported types and required data
- `function_plot`: expressions, axes, bounds, units, domain restrictions. Use exact mathematical notation and appropriate plotting tools.
- `line_chart`, `bar_chart`, `scatter_plot`: named axes, units, explicit numerical data points, series names; distinguish illustrative from measured data.
- `binary_tree`: unique node IDs, values, left/right edges, explicit root; enforce no cycles, at most two children, one parent per nonroot node. If claiming BST, verify ordering invariant.
- `directed_graph`, `network_graph`: node IDs, directed/undirected edges, weights if relevant; verify connectivity and paths when required by the question.
- `flowchart`: node IDs, operation/decision types, labeled branches, entry/exit, valid transitions.
- `state_diagram`: states, initial state, transitions, events/guards; verify reachable states and transition behavior.

## Workflow
1. Determine whether a visual improves the objective (e.g. tracing a BST, reading a chart, interpreting network topology). Avoid decorative visuals.
2. Generate the underlying structured data first, then derive both the visible representation and grading answer from the same data.
3. Independently validate the answer and visual consistency; reject ambiguous node labels, missing axes/units, impossible graphs, and visual leaks of the answer.
4. Render with available native visualization tools, SVG, or Mermaid; fall back to text-based diagrams or adjacency lists. Do not assume a tool is installed.
5. Present alt text or equivalent accessible description. Do not reveal hidden answer keys.
6. Grade using existing methods; for node-selection or drag interactions, only claim interactivity if supported, otherwise request IDs or ordered sequences as text.
7. On retry, vary topology, values, labels, or scale while preserving the learning objective.

## Examples
- Tracing: show a BST; ask for postorder sequence. Compute answer via traversal over node-edge data.
- Application: show a weighted network; ask which route is shortest. Verify using a shortest-path algorithm and state assumptions about direction/weights.
- Calculation: show a plotted function and ask for an exact value only if its coordinates are unambiguous; otherwise provide the expression or data table.
- Conceptual: show a flowchart; ask why a branch is taken for a given input.

Visual interaction is not guaranteed by this skill; the host UI determines actual interactive capabilities.

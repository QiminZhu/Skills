---
name: review-mode
description: Review previously studied lectures or topics with adaptive retrieval, immediate diagnostic feedback, targeted relearning, and evidence-based spaced review. Use for explicit Review Mode, revision, knowledge-gap checks, retention practice, or review of lecture material; route reviews of project submissions to project-assessment instead.
---

## Session-only override
When the learner requests session-only learning or arrives from the Teach, Practice, Next flow, do not read/write learner records, track mastery, synchronize results, export assessment evidence, or schedule reviews. Preserve only temporary conversation context and assistance history. This instruction overrides record/scheduling guidance below until the learner explicitly requests a change. Apply `../learn-combined/references/interactive-lesson.md` to any teaching or interactive practice during this session.

# Review Mode

Purpose: strengthen and verify existing knowledge, not repeat an entire lecture. Respect an explicit mode choice. For new teaching use `../learn-combined/SKILL.md`; for assessment of project deliverables use `../project-assessment/SKILL.md`.

## Start
Identify lecture/topic and scope from supplied materials or context; ask only if missing. Use supplied sources first, cite identifiable sections, and disclose inaccessible coverage. Use existing learning records if authorized and available; otherwise state that evidence is session-only. Honor requested time, number of questions, or format. No mandatory onboarding. Do not infer mastery from prior exposure.

## Adaptive review loop
Apply `../learn-combined/references/scaffolded-independence.md` when diagnosing errors, giving hints, or verifying performance after relearning. This extends the loop below without changing the original result of any submitted review attempt.

1. Map concepts and learning objectives; preserve coverage of the requested lecture.
2. Select one question according to [review-policy.md](references/review-policy.md), prioritizing due recall, recurring gaps, unsupported success, and unassessed concepts without starving other objectives.
3. Ask for an unaided recall, explanation, application, calculation, or tracing response. Default one question per turn; no hints before independent submission. Honor batches and explicit requests for help.
4. Immediately evaluate the submitted answer with precise, brief feedback; distinguish correctness from reasoning and independent from prompted/scaffolded evidence. For an obvious slip, one brief self-check is enough. Otherwise ask the learner to locate the breakdown, compare that diagnosis with the actual work, and classify the cause only when supported: conceptual, procedural, strategic, representational, missing prerequisite, ambiguous task, or unclear/mixed. Never rewrite the original assessment result after diagnosis.
5. Automatically enter a short targeted Learning Mode intervention for a demonstrated gap (not merely a single ambiguous slip), without resetting review progress. Explain the smallest source-grounded missing principle. If help is needed, use the lowest useful hint and require an attempted next step before escalation. Then offer a fresh Unassisted Evidence Checkpoint. During its independent window provide no target-skill cues; if the learner requests help, close the window and tag resumed work as scaffolded. Explicit learner requests override automatic transitions.
6. Adapt difficulty and topic based on independent evidence. Maintain lecture coverage, avoid repeatedly testing a single weakness, and stop at the requested budget.

Read `../learn-combined/references/assessment.md`, `../learn-combined/references/feedback.md`, and `../learn-combined/references/quiz-design.md` for grading and feedback. Keep recognition, explanation, familiar application, and transfer separate; a single correct answer is not durable mastery. Do not assign invented numerical mastery scores.

## Records and scheduling
Reuse `../learn-combined/references/records.md` and `../learn-combined/references/scheduling.md` without changing their schemas or FSRS requirements. Preserve immutable attempt evidence, support level, misconception notes, and original result; add follow-up attempts separately. Schedule fixed recall items only from unaided recall evidence; do not use assisted success as proof of unaided recall. Use tested FSRS only when actually available, otherwise disclose the specified simple-review-v1 fallback. Do not claim records saved or reminders scheduled without verified execution.

## Response style and close
Question first; after each attempt, give immediate concise correctness feedback, specific reasoning diagnosis, and one next move. Avoid lengthy lecture restatements unless a gap warrants reteaching or user requests an explanation. End with independently demonstrated abilities, supported performance, unverified objectives, recurring gaps, coverage, and next recommended review (when available). Do not confuse memory stability with conceptual mastery.
